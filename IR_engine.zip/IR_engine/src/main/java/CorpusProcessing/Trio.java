package CorpusProcessing;

import java.io.Serializable;

/**
 * Represents a group of three elements.
 */
public abstract class Trio implements Comparable<Trio>, Serializable {
}
